﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template
{
    abstract class CardTemplate
    {
        public void BuildCard()
        {
            AddHeader();
            AddBody();
            AddFooter();
            SaveToFile();
        }

        public abstract void AddHeader();
        public abstract void AddBody();
        public abstract void AddFooter();
        public virtual void SaveToFile()
        { }
    }
    class BirthdayCard : CardTemplate
    {
        public override void AddHeader()
        {
            Console.WriteLine("");
            Console.WriteLine("═════════════════════════════════════════");
            Console.WriteLine("║-----Adding Birthday Card Header-------║");
            Console.WriteLine("║                                       ║");
            Console.WriteLine("║         З Днем Народження!            ║");
        }

        public override void AddBody()
        {
            Console.WriteLine("║                                       ║");
            Console.WriteLine("║-------Adding Birthday Card Body-------║");
            Console.WriteLine("║                                       ║");
            Console.WriteLine("║             *  *  *  *  *  *          ║");
            Console.WriteLine("║           *  *  *  *  *  *  *         ║");
            Console.WriteLine("║            *  *  *  *  *  *           ║");
        }

        public override void AddFooter()
        {
            Console.WriteLine("║                                       ║");
            Console.WriteLine("║               Вітаємо з               ║");
            Console.WriteLine("║            особливим днем!            ║");
            Console.WriteLine("║                                       ║");
            Console.WriteLine("║-------Adding Birthday Card Footer-----║");
            Console.WriteLine("║                                       ║");
            Console.WriteLine("║═══════════════════════════════════════║");
        }

        public override void SaveToFile()
        {
            using (StreamWriter writer = new StreamWriter("birthday_card.txt"))
            {
                writer.WriteLine("Birthday Card:");
                AddHeaderToFile(writer);
                AddBodyToFile(writer);
                AddFooterToFile(writer);
            }
        }

        private void AddHeaderToFile(StreamWriter writer)
        {
            writer.WriteLine("");
            writer.WriteLine("═════════════════════════════════════════");
            writer.WriteLine("║-----Adding Birthday Card Header-------║");
            writer.WriteLine("║                                       ║");
            writer.WriteLine("║         З Днем Народження!            ║");
        }

        private void AddBodyToFile(StreamWriter writer)
        {
            writer.WriteLine("║                                       ║");
            writer.WriteLine("║-------Adding Birthday Card Body-------║");
            writer.WriteLine("║                                       ║");
            writer.WriteLine("║             *  *  *  *  *  *          ║");
            writer.WriteLine("║           *  *  *  *  *  *  *         ║");
            writer.WriteLine("║            *  *  *  *  *  *           ║");
        }

        private void AddFooterToFile(StreamWriter writer)
        {
            writer.WriteLine("║                                       ║");
            writer.WriteLine("║               Вітаємо з               ║");
            writer.WriteLine("║            особливим днем!            ║");
            writer.WriteLine("║                                       ║");
            writer.WriteLine("║-------Adding Birthday Card Footer-----║");
            writer.WriteLine("║                                       ║");
            writer.WriteLine("║═══════════════════════════════════════║");
        }
    }
    class AnniversaryCard : CardTemplate
    {
        public override void AddHeader()
        {
            Console.WriteLine("");
            Console.WriteLine("  //------------------------------------//");
            Console.WriteLine(" //   Adding Anniversary Card Header    //");
            Console.WriteLine("//______________________________________//");
        }

        public override void AddBody()
        {
            Console.WriteLine("|------Adding Anniversary Card Body-----|");
            Console.WriteLine("|  ___________________________________  |");
            Console.WriteLine("|  |                                 |  |");
            Console.WriteLine("|  |                                 |  |");
        }

        public override void AddFooter()
        {
            Console.WriteLine("|  | Adding Anniversary Card Footer  |  |");
            Console.WriteLine("|  |                                 |  |");
            Console.WriteLine("|  |_________________________________|  |");
            Console.WriteLine("|_______________________________________|");
        }
        public override void SaveToFile()
        {
            using (StreamWriter writer = new StreamWriter("Anniversary_card.txt"))
            {
                writer.WriteLine("Birthday Card:");
                AddHeaderToFile(writer);
                AddBodyToFile(writer);
                AddFooterToFile(writer);
            }
        }

        private void AddHeaderToFile(StreamWriter writer)
        {
            writer.WriteLine("");
            writer.WriteLine("  //------------------------------------//");
            writer.WriteLine(" //   Adding Anniversary Card Header    //");
            writer.WriteLine("//______________________________________//");
        }

        private void AddBodyToFile(StreamWriter writer)
        {
            writer.WriteLine("|------Adding Anniversary Card Body-----|");
            writer.WriteLine("|  ___________________________________  |");
            writer.WriteLine("|  |                                 |  |");
            writer.WriteLine("|  |                                 |  |");
        }

        private void AddFooterToFile(StreamWriter writer)
        {
            writer.WriteLine("|  | Adding Anniversary Card Footer  |  |");
            writer.WriteLine("|  |                                 |  |");
            writer.WriteLine("|  |_________________________________|  |");
            writer.WriteLine("|_______________________________________|");
        }
    }

    class InviteCard : CardTemplate
    {
        public override void AddHeader()
        {
            Console.WriteLine("");
            Console.WriteLine("*****************************************");
            Console.WriteLine("*                                       *");
            Console.WriteLine("*          ЗАПРОШЕННЯ                   *");
            Console.WriteLine("*                                       *");
            Console.WriteLine("*                                       *");
        }

        public override void AddBody()
        {
            Console.WriteLine("*   Запрошуємо вас на наше              *");
            Console.WriteLine("*   святкування!                        *");
            Console.WriteLine("*                                       *");
            Console.WriteLine("*   Дата: 10 квітня 2024 року           *");
            Console.WriteLine("*   Час: 18:00                          *");
            Console.WriteLine("*   Місце: Ресторан 'Смаколик'          *");
        }

        public override void AddFooter()
        {
            Console.WriteLine("*                                       *");
            Console.WriteLine("*      Будемо раді бачити вас!          *");
            Console.WriteLine("*                                       *");
            Console.WriteLine("*****************************************");
        }
        public override void SaveToFile()
        {
            using (StreamWriter writer = new StreamWriter("Invite_card.txt"))
            {
                writer.WriteLine("Birthday Card:");
                AddHeaderToFile(writer);
                AddBodyToFile(writer);
                AddFooterToFile(writer);
            }
        }

        private void AddHeaderToFile(StreamWriter writer)
        {
            writer.WriteLine("");
            writer.WriteLine("*****************************************");
            writer.WriteLine("*                                       *");
            writer.WriteLine("*          ЗАПРОШЕННЯ                   *");
            writer.WriteLine("*                                       *");
            writer.WriteLine("*                                       *");
        }

        private void AddBodyToFile(StreamWriter writer)
        {
            writer.WriteLine("*   Запрошуємо вас на наше              *");
            writer.WriteLine("*   святкування!                        *");
            writer.WriteLine("*                                       *");
            writer.WriteLine("*   Дата: 10 квітня 2024 року           *");
            writer.WriteLine("*   Час: 18:00                          *");
            writer.WriteLine("*   Місце: Ресторан 'Смаколик'          *");
        }

        private void AddFooterToFile(StreamWriter writer)
        {
            writer.WriteLine("*                                       *");
            writer.WriteLine("*      Будемо раді бачити вас!          *");
            writer.WriteLine("*                                       *");
            writer.WriteLine("*****************************************");
        }
    }
}
