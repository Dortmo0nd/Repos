﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Template
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        BirthdayCard headBirth = new BirthdayCard();
        AnniversaryCard headAnniv = new AnniversaryCard();
        InviteCard headInvite = new InviteCard();
        private void button1_Click(object sender, EventArgs e)
        {
            CardTemplate birthdayCard = new BirthdayCard();
            birthdayCard.BuildCard();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CardTemplate anniversaryCard = new AnniversaryCard();
            anniversaryCard.BuildCard();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CardTemplate inviteCard = new InviteCard();
            inviteCard.BuildCard();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            headBirth.AddHeader();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            headBirth.AddBody();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            headBirth.AddFooter();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            headAnniv.AddHeader();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            headAnniv.AddBody();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            headAnniv.AddFooter();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            headInvite.AddHeader();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            headInvite.AddBody();
        }

        private void button10_Click(object sender, EventArgs e)
        {

            headInvite.AddFooter();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            headBirth.SaveToFile();
            headInvite.SaveToFile();
            headAnniv.SaveToFile();
        }
    }
}
