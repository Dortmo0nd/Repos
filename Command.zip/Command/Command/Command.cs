﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;

namespace Command
{
   interface  ICommand
   {
       void Execute();
   }
    class Invoker
    {
        private ICommand _onStart;
        private ICommand _onFinish;

        public void SetOnStart(ICommand command)
        {
            this._onStart = command;
            this._onStart.Execute(); // Додано виклик методу Execute
        }

        public void SetOnFinish(ICommand command)
        {
            this._onFinish = command;
            this._onFinish.Execute(); // Додано виклик методу Execute
        }

        // Панель для розміщення кнопок
        public FlowLayoutPanel Panel { get; private set; }

        public Invoker()
        {
            // Ініціалізуємо панель
            Panel = new FlowLayoutPanel();
            Panel.Dock = DockStyle.Fill;
            Panel.FlowDirection = FlowDirection.TopDown;
        }


        public void CreateSaveButton()
        {
            Button saveButton = new Button();
            saveButton.Text = "Save Data";
            saveButton.Click += (sender, e) => SetOnStart(new SaveDataCommand());
            Panel.Controls.Add(saveButton);
            //SetOnStart(new SaveDataCommand()); // Додано виклик методу SetOnStart
        }

        // Метод для створення кнопки "Clear Data"
        public void CreateClearButton()
        {
            Button clearButton = new Button();
            clearButton.Text = "Clear Data";
            clearButton.Click += (sender, e) => SetOnFinish(new ClearDataCommand());
            Panel.Controls.Add(clearButton);
            //SetOnStart(new ClearDataCommand());
        }

        // Метод для створення кнопки "View Chart"
        public void CreateViewChartButton()
        {
            Button viewChartButton = new Button();
            viewChartButton.Text = "View Chart";
            viewChartButton.Click += (sender, e) => SetOnStart(new ViewChartCommand());
            Panel.Controls.Add(viewChartButton);
            //SetOnFinish(new ViewChartCommand());
        }

        // Метод для створення кнопки "View Diagram"
        public void CreateViewDiagramButton()
        {
            Button viewDiagramButton = new Button();
            viewDiagramButton.Text = "View Diagram";
            viewDiagramButton.Click += (sender, e) => SetOnFinish(new ViewDiagramCommand());
            Panel.Controls.Add(viewDiagramButton);
            //SetOnFinish(new ViewDiagramCommand());
        }

        // Метод для створення кнопки "View Report"
        public void CreateViewReportButton()
        {
            Button viewReportButton = new Button();
            viewReportButton.Text = "View Report";
            viewReportButton.Click += (sender, e) => SetOnStart(new ViewReportCommand());
            Panel.Controls.Add(viewReportButton);
            //SetOnFinish(new ViewReportCommand());
        }
    }
    class SaveDataCommand : ICommand
    {
        public void Execute()
        {
            Console.WriteLine("Збереження даних");
        }
    }

    class ClearDataCommand : ICommand
    {
        public void Execute()
        {
            Console.WriteLine("Очистка даних");
        }
    }

    class ViewChartCommand : ICommand
    {
        public void Execute()
        {
            Console.WriteLine("Перегляд графiку");
        }
    }

    class ViewDiagramCommand : ICommand
    {
        public void Execute()
        {
            Console.WriteLine("Перегляд дiаграми");
        }
    }

    class ViewReportCommand : ICommand
    {
        public void Execute()
        {
            Console.WriteLine("Перегляд звiту");
        }
    }

}
