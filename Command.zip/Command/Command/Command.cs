﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Command
{
    interface CommandI
    {
        string GetInfo();
        void Execute(List<object> parametres);
    }
    abstract class CommandBase: CommandI
    {
        protected string Name;
        protected string Description;

        public string GetInfo()
        {
            return $"{Name} - {Description}";
        }
        public abstract void Execute(List<object> parametres);
    }
     class FirstButton: CommandBase
     {
        public FirstButton()
        {
            Name = "";
            Description = "";
        }

        public override void Execute(List<object> parameters)
        {
            foreach (var param in parameters)
            {
                MessageBox.Show(param.ToString());
            }
        }
     }
    class SecondButton : CommandBase
    {
        public SecondButton()
        {
            Name = "";
            Description = "";
        }

        public override void Execute(List<object> parameters)
        {
            foreach (var param in parameters)
            {
                MessageBox.Show(param.ToString());
            }
        }
    }
    class ThirdButton : CommandBase
    {
        public ThirdButton()
        {
            Name = "";
            Description = "";
        }

        public override void Execute(List<object> parameters)
        {
            foreach (var param in parameters)
            {
                MessageBox.Show(param.ToString());
            }
        }
    }
    class FourthButton : CommandBase
    {
        public FourthButton()
        {
            Name = "";
            Description = "";
        }

        public override void Execute(List<object> parameters)
        {
            foreach (var param in parameters)
            {
                MessageBox.Show(param.ToString());
            }
        }
    }
    class FifthButton : CommandBase
    {
        public FifthButton()
        {
            Name = "";
            Description = "";
        }

        public override void Execute(List<object> parameters)
        {
            foreach (var param in parameters)
            {
                MessageBox.Show(param.ToString());
            }
        }
    }
}
