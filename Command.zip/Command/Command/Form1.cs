﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Command
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        CommandI showCommand = new ForAllButton();

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            showCommand.Execute(new List<object> { "Перша кнопка", "Вона відправляє дані до бази даних для роботи з графіком або Excel файлом" });
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            showCommand.Execute(new List<object> { "Це кнопка очистки даних", "Вона очищає всі дані з бази даних, якщо вони застарілі або не потрібні" });
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            showCommand.Execute(new List<object> { "Це кнопка перегляду графіку", "Вона відкриває форму з графіком де показані витрати ресурів за певний проміжок часу" });
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            showCommand.Execute(new List<object> { "Це кнопка призначена для перегляду діаграми", "Вона дає доступ до перегляду діаграми на головній діаграмі" });
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            showCommand.Execute(new List<object> { "Це кнопка для перегляду звітності", "Вона відкриває форму для роботи з Excel файлом" });
        }
    }
}
