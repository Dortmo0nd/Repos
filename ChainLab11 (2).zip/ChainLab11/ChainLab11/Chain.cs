﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChainLab11
{
    public interface IHandler
    {
        bool Accept(string ipAdress);
        IHandler SetNext(IHandler handler);
    }
    public abstract class BaseFilterIP : IHandler
    {
        protected IHandler handlerNext;
        public IHandler SetNext(IHandler filter) 
        { 
            handlerNext = filter;
            return filter;
        }
        public virtual bool Accept(string ipAdress)
        {
            if (handlerNext != null)
            {
                return false;
            }
            return true;
        }
    }
    public class PrivateIP : BaseFilterIP
    {
        public override bool Accept(string ipAdress)
        {
            if(ipAdress.StartsWith("192.168.") || ipAdress.StartsWith("10."))
            {
                return false;
            }
            return true;
        }
    }
    public class standartIP : BaseFilterIP
    {
        public List<string> List_Ip;
        public standartIP(List<string> list_Ip) 
        {
            this.List_Ip = list_Ip;
        }
        public override bool Accept(string ipAdres)
        {
            if (!List_Ip.Contains(ipAdres))
            {
                return false;
            }
            return true;
        }
    }
}
