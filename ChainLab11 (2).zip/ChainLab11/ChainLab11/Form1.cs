﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChainLab11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        static List<string> list_ip = new List<string>
        {
            "192.168.1.1","126.0.0.1","126.0.1.1","128.0.0.1","192.168.1.0","203.0.113.10","203.0.123.11","203.0.113.10","10.1.1.1","10.1.2.3",
            "192.168.0.0","128.1.1.1","126.3.1.1","128.4.2.1","192.168.1.2","203.1.102.12","203.3.133.5","203.5.1.1","10.1.2.2","10.3.2.1"
        };
        public IHandler privateIP = new PrivateIP();
        public IHandler standartIP = new standartIP(list_ip);

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            privateIP.SetNext(standartIP);
            foreach (var ipAdres in list_ip)
            {
                bool accept = privateIP.Accept(ipAdres);
                listBox1.Items.Add($"{ipAdres} - {(accept ? "Дозвіл" : "Заборона")}");
            }
        }
    }
}
