﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ChainLab11;
using System.Collections.Generic;

namespace UnitTestChainLab11
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var privateIP = new ChainLab11.PrivateIP();
            Assert.IsFalse(privateIP.Accept("192.168.1.1"));
            Assert.IsFalse(privateIP.Accept("192.168.1.0"));
            Assert.IsFalse(privateIP.Accept("192.168.1.2"));
            Assert.IsFalse(privateIP.Accept("192.168.0.0"));
            Assert.IsFalse(privateIP.Accept("10.1.1.1"));
            Assert.IsFalse(privateIP.Accept("10.1.2.3"));
            Assert.IsFalse(privateIP.Accept("10.3.2.1"));
            Assert.IsFalse(privateIP.Accept("10.1.2.2"));

            //Assert.IsFalse(privateIP.Accept("126.0.0.1"));
            //Assert.IsFalse(privateIP.Accept("126.0.1.1"));
            //Assert.IsFalse(privateIP.Accept("128.0.0.1"));
        }

        [TestMethod]
        public void TestMethod2()
        {
            var list_ip = new List<string>
            {
                "192.168.1.1","126.0.0.1","126.0.1.1","128.0.0.1","192.168.1.0","203.0.113.10","203.0.123.11","203.0.113.10","10.1.1.1","10.1.2.3",
                "192.168.0.0","128.1.1.1","126.3.1.1","128.4.2.1","192.168.1.2","203.1.102.12","203.3.133.5","203.5.1.1","10.1.2.2","10.3.2.1"
            };
            var standartIP = new ChainLab11.standartIP(list_ip);

            Assert.IsTrue(standartIP.Accept("126.0.0.1"));
            Assert.IsTrue(standartIP.Accept("126.0.1.1"));
            Assert.IsTrue(standartIP.Accept("128.0.0.1"));
            Assert.IsTrue(standartIP.Accept("203.0.113.10"));
            Assert.IsTrue(standartIP.Accept("203.0.123.11"));
            Assert.IsTrue(standartIP.Accept("203.0.113.10"));
            Assert.IsTrue(standartIP.Accept("128.1.1.1"));
            Assert.IsTrue(standartIP.Accept("126.3.1.1"));
            Assert.IsTrue(standartIP.Accept("128.4.2.1"));
            Assert.IsTrue(standartIP.Accept("203.1.102.12"));
            Assert.IsTrue(standartIP.Accept("203.3.133.5"));
            Assert.IsTrue(standartIP.Accept("203.5.1.1"));

            //Assert.IsFalse(standartIP.Accept("192.168.1.1"));
            //Assert.IsFalse(standartIP.Accept("192.168.1.0"));
            //Assert.IsFalse(standartIP.Accept("192.168.1.2"));
        }
    }
}
