﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Builder
{
     public class SpellChecker
     {
        private HashSet<string> dictionary = new HashSet<string>();
        public void AddToDictionary(string word)
        {
            dictionary.Add(word.ToLower());
        }

        public bool CheckSpelling(string word)
        {
            string cleanedWord = CleanWord(word);

            bool isSpelledCorrectly = dictionary.Contains(cleanedWord.ToLower());

            if (isSpelledCorrectly)
            {
                MessageBox.Show($"Речення/слово '{word}' вірно написане.");
            }
            else
            {
                MessageBox.Show($"Помилка: '{word}' речення/слово написене не вірно.");
            }

            return isSpelledCorrectly;
        }
        private string CleanWord(string word)
        {
            StringBuilder cleanedWord = new StringBuilder();
            foreach (char c in word)
            {
                if (char.IsLetter(c) || c == ' ' || c == ',' || c == '.' || c == '?' || c == '!')
                {
                    cleanedWord.Append(c);
                }
            }
            return cleanedWord.ToString();
        }
    }
}
