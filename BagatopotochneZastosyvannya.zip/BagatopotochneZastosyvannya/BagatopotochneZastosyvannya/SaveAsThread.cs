﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BagatopotochneZastosyvannya
{
    class SaveAsThread
    {
        private int[] array;
        private string file;
        public SaveAsThread(int[] array, string file)
        {
            this.array = array;
            this.file = file;
        }
        private void SaveArrayToFile()
        {
            using (StreamWriter writer = new StreamWriter(file))
            {
                foreach (int num in array)
                {
                    writer.WriteLine(num);
                }
            }
        }
        public void Start()
        {
            Thread thread = new Thread(SaveArrayToFile);
            thread.Start();
        }

        public void Max()
        {
            int max = 0;
            for(int i = 0; i < array.Length; i++) 
            {
                if (array[i] > max)
                {
                    max = array[i];
                }
            }
            MessageBox.Show("Максимальний елемент масиву: " + max);
        }
        public void StartMax()
        {
            Thread thread = new Thread(Max);
            thread.Start();
        }
        public void Min()
        {
            int min = 0;
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] < min)
                {
                    min = array[i];
                }
            }
            MessageBox.Show("Мінімальний елемент масиву: " + min);
        }
        public void StartMin()
        {
            Thread thread = new Thread(Min);
            thread.Start();
        }
        public void insertion_sort()
        {
            //for (int i = 1; i < array.Length; i++)
            //{
            //    int j = i - 1;

            //    while (j >= 0 && array[j] > array[i])
            //    {
            //        array[j + 1] = array[j];
            //        j--;
            //    }
            //    array[j + 1] = array[i];
            //}



            int n = array.Length;
            for (int i = 1; i < n; i++)
            {
                int key = array[i];
                int j = i - 1;
                while (j >= 0 && array[j] > key)
                {
                    array[j + 1] = array[j];
                    j--;
                }
                array[j + 1] = key;
            }
        }
        public void sorting_choice()
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < array.Length; j++)
                {
                    if (array[j] < array[minIndex])
                    {
                        minIndex = j;
                    }
                }

                int temp = array[minIndex];
                array[minIndex] = array[i];
                array[i] = temp;
            }
        }
        public void bubble_sort()
        {
            int x;
            for(int i = 0; i < array.Length; i++)
            {
                for(int j = 0; j<array.Length-1;j++)
                {
                    if (array[j] > array[j+1])
                    {
                        x = array[j];
                        array[j] = array[j + 1];
                        array[j+1] = x;
                    }
                }
            }
        }
        public void StartBubble()
        {
            Thread thread = new Thread(bubble_sort);
            thread.Start();
        }
        public void StartSortByChoice()
        {
            Thread thread = new Thread(sorting_choice);
            thread.Start();
        }
        public void StartInsertion()
        {
            Thread thread = new Thread(insertion_sort);
            thread.Start();
        }
    }
}
