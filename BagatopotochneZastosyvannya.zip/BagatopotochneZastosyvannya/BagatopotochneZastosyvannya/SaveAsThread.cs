﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BagatopotochneZastosyvannya
{
    class SaveAsThread
    {
        private int[] array;
        private string file;
        public SaveAsThread(int[] array, string file)
        {
            this.array = array;
            this.file = file;
        }
        private void SaveArrayToFile()
        {
            using (StreamWriter writer = new StreamWriter(file))
            {
                foreach (int num in array)
                {
                    writer.WriteLine(num);
                }
            }
        }
        public void Start()
        {
            Thread thread = new Thread(SaveArrayToFile);
            thread.Start();
        }
    }
}
