﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BagatopotochneZastosyvannya
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void FillArr(int[] array)
        {
            Random random = new Random();
            for(int i =0; i< array.Length; i++) 
            {
                array[i] = random.Next(-50, 50);
            }
        }
        public int[] array1, array2, array3;
        private void button1_Click(object sender, EventArgs e)
        {
            int size1 = Convert.ToInt32(textBox1.Text);
            if (size1 >100 || size1 < 0 || size1 == 0)
            {
                MessageBox.Show("Число має бути більшим 0 та != 0, і не більше 100");
                textBox1.Text = "";
            }
            else
            {
                array1 = new int[size1];
                FillArr(array1);
                listBox1.Items.Clear();
                foreach (int x in array1)
                {
                    listBox1.Items.Add(x);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int size2 = Convert.ToInt32(textBox2.Text);
            if (size2 > 100 || size2 < 0 || size2 == 0)
            {
                MessageBox.Show("Число має бути більшим 0 та != 0, і не більше 100");
                textBox2.Text = "";
            }
            else
            {
                array2 = new int[size2];
                FillArr(array2);
                listBox2.Items.Clear();
                foreach (int x in array2)
                {
                    listBox2.Items.Add(x);
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SaveAsThread arr1 = new SaveAsThread(array1, "");
            arr1.StartMin();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SaveAsThread arr1_1 = new SaveAsThread(array1, "");
            arr1_1.StartMax();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SaveAsThread arr2 = new SaveAsThread(array2, "");
            arr2.StartMin();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            SaveAsThread arr2 = new SaveAsThread(array2, "");
            arr2.StartMax();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            SaveAsThread arr3 = new SaveAsThread(array3, "");
            arr3.StartMin();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            SaveAsThread arr1 = new SaveAsThread(array3, "");
            arr1.StartMax();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            SaveAsThread bubble = new SaveAsThread(array1, "");
            bubble.StartBubble();
            listBox1.Items.Clear();
            foreach (int x in array1)
            {
                listBox1.Items.Add(x);
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            SaveAsThread choice = new SaveAsThread(array2, "");
            choice.StartSortByChoice();
            listBox2.Items.Clear();
            foreach (int x in array2)
            {
                listBox2.Items.Add(x);
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            SaveAsThread Insertation = new SaveAsThread(array3, "");
            Insertation.StartInsertion();
            listBox3.Items.Clear();
            foreach (int x in array3)
            {
                listBox3.Items.Add(x);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int size3 = Convert.ToInt32(textBox3.Text);
            if (size3 > 100 || size3 < 0 || size3 == 0)
            {
                MessageBox.Show("Число має бути більшим 0 та != 0, і не більше 100");
                textBox3.Text = "";
            }
            else
            {
                array3 = new int[size3];
                FillArr(array3);
                listBox3.Items.Clear();
                foreach (int x in array3)
                {
                    listBox3.Items.Add(x);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                SaveAsThread thread1 = new SaveAsThread(array1, "First.txt");
                thread1.Start();
                SaveAsThread thread2 = new SaveAsThread(array2, "Second.txt");
                thread2.Start();
                SaveAsThread thread3 = new SaveAsThread(array3, "Third.txt");
                thread3.Start();
                MessageBox.Show("Дані збережено у файл");
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
