﻿using System;
using System.Windows.Forms;

namespace Mediator
{
    public partial class Form1 : Form
    {
        private IChatMediator _mediator;

        public Form1()
        {
            InitializeComponent();
            _mediator = new ChatMediator(listBox1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string userName = textBox2.Text;
            if (!string.IsNullOrWhiteSpace(userName))
            {
                var user = new ChatUser(_mediator, userName);
                _mediator.AddUser(user);
                listBox2.Items.Add(userName);
                textBox2.Clear();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string selectedUser = listBox2.SelectedItem.ToString();
            if (selectedUser != null)
            {
                string message = textBox1.Text;
                if (!string.IsNullOrWhiteSpace(message))
                {
                    var users = _mediator.GetUsers();
                    foreach (var user in users)
                    {
                        if (user.Name == selectedUser)
                        {
                            user.Send(message);
                        }
                    }
                    textBox1.Clear();
                }
            }
        }
    }
}
