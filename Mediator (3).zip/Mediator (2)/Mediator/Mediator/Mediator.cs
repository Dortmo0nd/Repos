﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mediator
{
    public interface IChatMediator
    {
        void SendMessage(User user, string message);
        List<User> GetUsers();
        void AddUser(User user);
    }
    public class ChatMediator : IChatMediator
    {
        private List<User> _users;
        private ListBox _messageListBox;

        public ChatMediator(ListBox messageListBox)
        {
            _users = new List<User>();
            _messageListBox = messageListBox;
        }

        public void AddUser(User user)
        {
            _users.Add(user);
        }

        public void SendMessage(User user, string message)
        {
            foreach (var u in _users)
            {
                if (u != user)
                {
                    u.Receive(message);
                }
            }

            _messageListBox.Items.Add($"{user.Name}: {message}");
        }

        public List<User> GetUsers()
        {
            return _users;
        }
    }

    public abstract class User
    {
        protected IChatMediator _mediator;
        public string Name;

        public User(IChatMediator mediator, string name)
        {
            _mediator = mediator;
            Name = name;
        }

        public abstract void Send(string message);
        public abstract void Receive(string message);
    }

    public class ChatUser : User
    {
        public ChatUser(IChatMediator mediator, string name) : base(mediator, name)
        {
        }

        public override void Send(string message)
        {
            _mediator.SendMessage(this, message);
        }

        public override void Receive(string message)
        {
        }
    }
}
