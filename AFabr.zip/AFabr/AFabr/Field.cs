﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AFabr
{
    public class Field_Fly_animal: Fly_abstract
    {
        public override void show(Form form)
        {
            Fly_picture = new PictureBox();
            Fly_picture.Image = (Image)Properties.Resources.ResourceManager.GetObject("Bird");
            Fly_picture.Top = 50;
            Fly_picture.SizeMode = PictureBoxSizeMode.StretchImage;
            form.Controls.Add(Fly_picture);
            Fly_picture.BackColor = Color.Transparent;
        }
    }
    public class Field_Crawl_animal: Crawl_abstract
    {
        public override void show(Form form)
        {
            Crawl_picture = new PictureBox();
            Crawl_picture.Image = (Image)Properties.Resources.ResourceManager.GetObject("Mouse");
            Crawl_picture.Top = 550;
            Crawl_picture.SizeMode = PictureBoxSizeMode.StretchImage;
            form.Controls.Add(Crawl_picture);
            Crawl_picture.BackColor = Color.Transparent;
        }
    }
    public class Field_Walk_animal: Walk_abstract
    {
        public override void show(Form form)
        {
            Walk_picture = new PictureBox();
            Walk_picture.Image = (Image)Properties.Resources.ResourceManager.GetObject("Snail2");
            Walk_picture.Top = 750;
            Walk_picture.SizeMode = PictureBoxSizeMode.StretchImage;
            form.Controls.Add(Walk_picture);
            Walk_picture.BackColor = Color.Transparent;
        }
    }
    public class FactoryField : AbstractFactory
    {
        override public Fly_abstract CreateFly()
        {
            return new Field_Fly_animal();
        }
        override public Crawl_abstract CreateCrawl()
        {
            return new Field_Crawl_animal();
        }
        override public Walk_abstract CreateWalk()
        {
            return new Field_Walk_animal();
        }
        public override void play()
        { 
            Form form1 = new Form();
            form1.BackgroundImage = (Image)Properties.Resources.ResourceManager.GetObject("Field");
            form1.Width = 1000;
            form1.Height = 500;
            fly = CreateFly();
            crawl = CreateCrawl();
            walk = CreateWalk();
            fly.show(form1);
            crawl.show(form1);
            walk.show(form1);
            form1.Show();
        }
    }
}
