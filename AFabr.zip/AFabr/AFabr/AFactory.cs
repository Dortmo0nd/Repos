﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AFabr
{
    public abstract class Fly_abstract
    {
        public PictureBox Fly_picture;
        public int place;
        public abstract void show(Form form);
    }
    public abstract class Crawl_abstract
    {
        public PictureBox Crawl_picture;
        public int place;
        public abstract void show(Form form);
    }
    public abstract class Walk_abstract
    {
        public PictureBox Walk_picture;
        public int place;
        public abstract void show(Form form);
    }
    public abstract class AbstractFactory
    {
        public Fly_abstract fly;
        public Crawl_abstract crawl;
        public Walk_abstract walk;
        abstract public Fly_abstract CreateFly();
        abstract public Crawl_abstract CreateCrawl();
        abstract public Walk_abstract CreateWalk();
        public abstract void play();
    }

}
