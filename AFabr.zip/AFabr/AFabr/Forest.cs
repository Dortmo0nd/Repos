﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AFabr
{
    public class Forest_Fly_animal : Fly_abstract
    {
        public override void show(Form form)
        {
            Fly_picture = new PictureBox();
            Fly_picture.Image = (Image)Properties.Resources.ResourceManager.GetObject("Bird");
            Fly_picture.SizeMode = PictureBoxSizeMode.StretchImage;
            Fly_picture.Top = 50;
            form.Controls.Add(Fly_picture);
            Fly_picture.BackColor = Color.Transparent;
        }
    }
    public class Forest_Crawl_animal : Crawl_abstract
    {
        public override void show(Form form)
        {
            Crawl_picture = new PictureBox();
            Crawl_picture.Image = (Image)Properties.Resources.ResourceManager.GetObject("Snail1");
            Crawl_picture.SizeMode = PictureBoxSizeMode.StretchImage;
            Crawl_picture.Top = 800;
            form.Controls.Add(Crawl_picture);
            Crawl_picture.BackColor = Color.Transparent;
        }
    }
    public class Forest_Walk_animal : Walk_abstract
    {
        public override void show(Form form)
        {
            Walk_picture = new PictureBox();
            Walk_picture.Image = (Image)Properties.Resources.ResourceManager.GetObject("Fox");
            Walk_picture.SizeMode = PictureBoxSizeMode.StretchImage;
            Walk_picture.Top = 700;
            form.Controls.Add(Walk_picture);
            Walk_picture.BackColor = Color.Transparent;
        }
    }
    public class FactoryForest : AbstractFactory
    {
        override public Fly_abstract CreateFly()
        {
            return new Forest_Fly_animal();
        }
        override public Crawl_abstract CreateCrawl()
        {
            return new Forest_Crawl_animal();
        }
        override public Walk_abstract CreateWalk()
        {
            return new Forest_Walk_animal();
        }
        public override void play()
        {
            Form form1 = new Form();
            form1.BackgroundImage = (Image)Properties.Resources.ResourceManager.GetObject("Forest");
            form1.Width = 1000;
            form1.Height = 500;
            fly = CreateFly();
            crawl = CreateCrawl();
            walk = CreateWalk();
            fly.show(form1);
            crawl.show(form1);
            walk.show(form1);
            form1.Show();
        }
    }
}
