﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AFabr
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        AbstractFactory Forest;
        AbstractFactory Field;
        AbstractFactory Jungle;
        private void button1_Click(object sender, EventArgs e)
        {
            Forest = new FactoryForest();
            Forest.play();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Field = new FactoryField();
            Field.play();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Jungle = new FactoryJungle();
            Jungle.play();
        }
    }
}
