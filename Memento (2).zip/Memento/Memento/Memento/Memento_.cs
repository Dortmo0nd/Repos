﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memento
{
    public interface IMemento
    {
        List<Point> GetState();
    }

    public class ConcreteMemento : IMemento
    {
        private List<Point> state;

        public ConcreteMemento(List<Point> state)
        {
            this.state = state;
        }

        public List<Point> GetState()
        {
            return new List<Point>(state);
        }
    }
    public class Caretaker
    {
        private Stack<IMemento> mementos = new Stack<IMemento>();

        public void Backup(IMemento memento)
        {
            List<Point> deepCopy = memento.GetState().Select(p => new Point(p.X, p.Y)).ToList();
            mementos.Push(new ConcreteMemento(deepCopy));
        }

        public List<Point> Undo()
        {
            if (mementos.Count > 0)
            {
                return mementos.Pop().GetState();
            }
            else
            {
                return new List<Point>();
            }
        }
    }
    public class Originator
    {
        public IMemento CreateSnapshot(List<Point> state)
        {
            return new ConcreteMemento(state);
        }

        public List<Point> RestoreSnapshot(IMemento memento)
        {
            if (memento is ConcreteMemento concreteMemento)
            {
                return concreteMemento.GetState();
            }
            else
            {
                throw new ArgumentException( memento.GetType().ToString());
            }
        }
    }
}
