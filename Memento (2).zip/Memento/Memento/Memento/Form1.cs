﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Memento
{
    public partial class Form1 : Form
    {
        private Caretaker caretaker;
        private Originator originator;
        private List<Point> points = new List<Point>();
        private PictureBox canvas = new PictureBox();
        public Form1()
        {
            InitializeComponent();
            caretaker = new Caretaker();
            canvas = new PictureBox();

            canvas.Dock = DockStyle.Fill;
            canvas.BackColor = Color.White;
            canvas.Paint += Form1_Paint;
            canvas.MouseClick += Form1_MouseClick;

            button3.Dock = DockStyle.Top;
            button3.Click += button3_Click;

            button4.Dock = DockStyle.Top;
            button4.Click += button4_Click;

            Controls.Add(canvas);
            Controls.Add(button3);
            Controls.Add(button4);

            originator = new Originator();
            caretaker = new Caretaker();
        }

        private void button4_Click(object sender, EventArgs e)//undo
        {
            points = caretaker.Undo();
            canvas.Refresh();
        }

        private void button3_Click(object sender, EventArgs e)//save
        {
            caretaker.Backup(originator.CreateSnapshot(points));
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            points.Add(e.Location);
            canvas.Refresh();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (points.Count > 1)
            {
                e.Graphics.DrawLines(Pens.Black, points.ToArray());
            }
        }
    }
}
