﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Nabluedatel.Sposterigach;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Nabluedatel
{
    public partial class Form1 : Form
    {
        private Subject subject = new Subject();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string mail = comboBox1.SelectedItem?.ToString();
            if (textBox1.Text != "" || mail != "")
            {
                subject.AddUserAndMailing(textBox1.Text, mail);
                comboBox1.Text = "";
            }
            else
            {
                MessageBox.Show("Будь ласка, введіть ім'я користувача та виберіть розсилку!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(textBox2.Text != "")
            {
                subject.RemoveUserAndMailing(textBox2.Text);
                textBox2.Text = "";
            }
            else
            {
                MessageBox.Show("Будь ласка введіть ім'я користувача для видалення");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Sposterigach_Interface observer = new Sposterigach(listBox1);
            subject.Attach(observer);
        }
    }
}
