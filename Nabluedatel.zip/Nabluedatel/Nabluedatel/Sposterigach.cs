﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nabluedatel
{
    public interface Sposterigach_Interface
    {
        void Update(Dictionary<string, string> mailings);
    }
    public class Sposterigach : Sposterigach_Interface
    {
        private ListBox listBox;

        public Sposterigach(ListBox listBox)
        {
            this.listBox = listBox;
        }

        public void Update(Dictionary<string, string> mailings)
        {
            listBox.Items.Clear();

            foreach (var x in mailings)
            {
                listBox.Items.Add($"{x.Key} - {x.Value}");
            }
        }
        public class Subject
        {
            private List<Sposterigach_Interface> observers = new List<Sposterigach_Interface>();
            private Dictionary<string, string> mailings = new Dictionary<string, string>();

            //Додати спостерігача
            public void Attach(Sposterigach_Interface observer)
            {
                observers.Add(observer);
            }


            // Надіслати повідомлення спостерігачу
            private void Notify()
            {
                foreach (var observer in observers)
                {
                    observer.Update(mailings);
                }
            }

            public void AddUserAndMailing(string userName, string mail)
            {
                mailings[userName] = mail;
                Notify();
            }

            public void RemoveUserAndMailing(string userName)
            {
                mailings.Remove(userName);
                Notify();
            }
        }
    }
}
