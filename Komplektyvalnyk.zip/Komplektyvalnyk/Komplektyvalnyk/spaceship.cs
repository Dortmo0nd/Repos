﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Komplektyvalnyk
{
    class Component
    {
        public virtual void draw() {}
        public virtual string Info() { return ""; }
        public string imagePath;
        public string ImagePath
        {
            get { return imagePath; }
            set { imagePath = value; }
        }

        public Image GetImage()
        {
            if (!string.IsNullOrEmpty(imagePath))
            {
                return Image.FromFile(imagePath);
            }
            else
            {
                return null;
            }
        }
    }

    class BaseSpaceship : Component
    {
        public override void draw() { }
        public override string Info()
        {
            return "Base SpaceShip";
        }
    }

    class StageRocket : BaseSpaceship
    {
        public override void draw() { }
        public override string Info()
        {
            return "Additional stage";
        }
    }

    class SpaceSatellite : BaseSpaceship
    {
        public override void draw() { }
        public override string Info()
        {
            return "Satellite on rocket";
        }
    }

    class Container : Component
    {
        public List<Component> components = new List<Component>();
        public ImageList imageList = new ImageList();
        public override string Info()
        {
            string s = "+";
            foreach (Component c in components)
                s += c.Info() + " \n";

            return s;
        }
    }
}
