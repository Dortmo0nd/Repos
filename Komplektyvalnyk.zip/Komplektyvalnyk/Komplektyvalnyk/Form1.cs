﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Komplektyvalnyk
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Container spaceShip = new Container();
        private void button1_Click(object sender, EventArgs e)
        {
            BaseSpaceship baseSpaceship = new BaseSpaceship();
            spaceShip.components.Add(baseSpaceship);
            listBox1.Items.Add(baseSpaceship.Info());
            baseSpaceship.ImagePath = "Spaceship.png";
            pictureBox1.Image = baseSpaceship.GetImage();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            spaceShip.components.Add(new StageRocket());
            listBox1.Items.Add(spaceShip.Info());
            spaceShip.ImagePath = "Spaceship2.png";
            pictureBox1.Image = spaceShip.GetImage();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Container spaceSattelite = new Container();
            spaceSattelite.components.Add(new SpaceSatellite());
            spaceShip.components.Add(spaceSattelite);
            listBox1.Items.Add(spaceShip.Info());
            spaceSattelite.ImagePath = "Spaceship3.png";
            pictureBox1.Image = spaceSattelite.GetImage();
        }
    }
}
