﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;

namespace Command
{
   interface  ICommand
   {
       void Execute();
       string GetInfo();
   }
    class Invoker
    {
        private ICommand _onStart;

        public void SetOnStart(ICommand command)
        {
            this._onStart = command;
            this._onStart.Execute(); 
        }

        public FlowLayoutPanel Panel { get; private set; }

        public Invoker()
        {
            Panel = new FlowLayoutPanel();
            Panel.Dock = DockStyle.Fill;
            Panel.FlowDirection = FlowDirection.TopDown;
        }

        public void createBtn(ICommand cmd)
        {
            Button btn = new Button();
            btn.Text = cmd.GetInfo();
            btn.Click += (sender, e) => SetOnStart(cmd);
            Panel.Controls.Add(btn);
        }

        public void createUI(List<ICommand> _cmds)
        {
            foreach (ICommand cmd in _cmds)
            {
                createBtn(cmd);
            }
        }
    }
    class SaveDataCommand : ICommand
    {
        public void Execute()
        {
            Console.WriteLine("Збереження даних");
            Form f = new Form();
            f.Text = "Збереження даних";
            f.Show();
        }
        public string GetInfo()
        {
            return "Save";
        }
    }

    class ClearDataCommand : ICommand
    {
        public void Execute()
        {
            Console.WriteLine("Очистка даних");
            Form f1 = new Form();
            f1.Text = "Очистка даних";
            f1.Show();
        }
        public string GetInfo()
        {
            return "Clear";
        }
    }

    class ViewChartCommand : ICommand
    {
        public void Execute()
        {
            Console.WriteLine("Перегляд графiку");
            Form f2 = new Form();
            f2.Text = "Перегляд графіку";
            f2.Show();
        }
        public string GetInfo()
        {
            return "Graphic";
        }
    }

    class ViewDiagramCommand : ICommand
    {
        public void Execute()
        {
            Console.WriteLine("Перегляд дiаграми");
            Form f3 = new Form();
            f3.Text = "Перегляд дiаграми";
            f3.Show();
        }
        public string GetInfo()
        {
            return "Diagrama";
        }
    }

    class ViewReportCommand : ICommand
    {
        public void Execute()
        {
            Console.WriteLine("Перегляд звiту");
            Form f4 = new Form();
            f4.Text = "Перегляд звiту";
            f4.Show();
        }
        public string GetInfo()
        {
            return "Report";
        }
    }
}
