﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Command
{
    public partial class Form1 : Form
    {
        private Invoker invoker;
        List<ICommand> cmds = new List<ICommand>() { new SaveDataCommand(), new ClearDataCommand(), new ViewChartCommand(), new ViewDiagramCommand(), new ViewReportCommand()};
        public Form1()
        {
            InitializeComponent();
            this.invoker = new Invoker();
            //invoker.CreateSaveButton();
            invoker.createUI(cmds);
            this.Controls.Add(invoker.Panel);
        }
    }
}
