﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProxyLab
{
    public partial class Form1 : Form
    {
        private IDatabase database;
        public Form1()
        {
            InitializeComponent();
            database = new DatabaseProxy("BaseForLab.mdb");
        }
        private void RefreshUserList()
        {
            List<User> users = database.GetAllUsers();
            dataGridView1.DataSource = users;
        }

        private void button2_Click(object sender, EventArgs e)//add
        {
            string userName = textBox2.Text;
            if (userName != "")
            {
                User newUser = new User { UserName = userName };
                database.AddUser(newUser);
                RefreshUserList();
            }
            else
            {
                MessageBox.Show("Введіть ім'я користувача");
            }
            textBox2.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)//delete
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedUserId = (int)dataGridView1.SelectedRows[0].Cells["Id"].Value;
                database.RemoveUser(selectedUserId);
                RefreshUserList();
            }
            else
            {
                MessageBox.Show("Виберіть користувача для видалення.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RefreshUserList();
        }
    }
}
