﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace ProxyLab
{
    public class User
    {
        public int Id { get; set; }
        public string UserName { get; set; }
    }
    public interface IDatabase
    {
        List<User> GetAllUsers();
        void AddUser(User user);
        void RemoveUser(int userId);
    }

    public class DatabaseService : IDatabase
    {
        private string connectionString;

        public DatabaseService(string mdbFilePath)
        {
            connectionString = $"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={mdbFilePath};";
        }

        public List<User> GetAllUsers()
        {
            List<User> users = new List<User>();

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM user_";
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int userId = Convert.ToInt32(reader["Id"]);
                            string userName = reader["UserName"].ToString();
                            users.Add(new User { Id = userId, UserName = userName });
                        }
                    }
                }
            }

            return users;
        }

        public void AddUser(User user)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    string query = $"INSERT INTO user_ (UserName) VALUES ('{user.UserName}')";
                    using (OleDbCommand command = new OleDbCommand(query, connection))
                    {
                        command.ExecuteNonQuery();
                    }

                    query = "SELECT @@IDENTITY AS NewId";
                    using (OleDbCommand command = new OleDbCommand(query, connection))
                    {
                        object result = command.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            user.Id = Convert.ToInt32(result);
                        }
                        else
                        {
                            MessageBox.Show("Не вдалося отримати нове значення Id.");
                        }
                    }
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
           
        }

        public void RemoveUser(int userId)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    string query = $"DELETE FROM user_ WHERE Id = {userId}";
                    using (OleDbCommand command = new OleDbCommand(query, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
           
        }
    }
    public class DatabaseProxy : IDatabase
    {
        private DatabaseService databaseService;

        public DatabaseProxy(string mdbFilePath)
        {
            databaseService = new DatabaseService(mdbFilePath);
        }

        public List<User> GetAllUsers()
        {
            return databaseService.GetAllUsers();
        }

        public void AddUser(User user)
        {
            databaseService.AddUser(user);
        }

        public void RemoveUser(int userId)
        {
            databaseService.RemoveUser(userId);
        }
    }
}
