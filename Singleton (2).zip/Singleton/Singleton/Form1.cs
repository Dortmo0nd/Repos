﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Singleton
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void Run()
        {
            // Використання глобальних точок доступу
            DBManager dbManager = DbManager.Instance;
            DocumentSaver documentSaver = DocumentSaver.Instance;
            Logger logger = Logger.Instance;

            // Робота з базою даних
            dbManager.Connect();
            dbManager.Query("SELECT * FROM table");

            // Збереження документу
            documentSaver.SaveDocument("Document content");

            // Логування операцій
            logger.Log("User performed an action");
        }
    }
}
