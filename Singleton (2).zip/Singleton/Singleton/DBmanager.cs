﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Singleton
{
    public class DBmanager
    {
        private SqlConnection con;
        private SqlCommand cmd;
        private static DBmanager instance;
        Logger logger;
    }
    private DBmanager()
    {
        logger = new Logger();
        con = new SqlConnection(@"Data Source=DESKTOP-ATQIGQ3;Initial Catalog=DoctorsFile;Integrated Security=True;");
        cmd = new SqlCommand();
        cmd.Connection = con;
    }
   
}
