﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton
{
    class Logger
    {
        private static Logger instance;

        private Logger() { /* приватний конструктор, щоб не можна було створити новий екземпляр безпосередньо */ }

        public static Logger Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Logger();
                }
                return instance;
            }
        }

        public void Log(string message)
        {
            // Логування повідомлення в файл чи інше місце
            Console.WriteLine($"[LOG] {DateTime.Now}: {message}");
        }
    }
}
