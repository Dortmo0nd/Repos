﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Visitor
{
    public partial class Form1 : Form
    {
        private ConfirmationVisitor vis = new ConfirmationVisitor();
        PhonePayment payment = new PhonePayment();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        { 
            payment.Accept(vis);
            MessageBox.Show(payment.Sent_message());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ConfirmationVisitor email = new ConfirmationVisitor();
            MessageBox.Show(email.VisitPhonePayment(payment));
        }
    }
}
