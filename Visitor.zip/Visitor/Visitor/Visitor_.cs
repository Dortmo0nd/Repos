﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Visitor
{
    public interface IComponent
    {
        void Accept(IVisitor visitor);
    }

    public class PhonePayment : IComponent
    {
        public void Accept(IVisitor visitor)
        {
            visitor.VisitPhonePayment(this);
        }
        public string name = "Jhon";
        public string cost = "9.99";
        public string Sent_message()
        {
            string mail = $"Hi, {name} confirm your payment on your phone, price {cost}";
            return mail;
        }
    }


    public interface IVisitor
    {
        string VisitPhonePayment(PhonePayment payment);
    }

    public class ConfirmationVisitor : IVisitor
    {
        public string VisitPhonePayment(PhonePayment payment)
        {
            string email_ = "jhon@gamil.com";
            string mail = $"Hi, {payment.name} confirm message on your email {email_}, price {payment.cost}";
            return mail;
        }
    }
}
