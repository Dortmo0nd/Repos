﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabrMethod
{
        public class CargoShip : AbstractTransoprt
        {
            public override string[] GetMassive()
            {
                string[] mas = { "Вид транспорту: " + Caption, "Вантаж: " + Cargo, "Точка А: " + PointA, "Точка Б: " + PointB };
                return mas;
            }
        }
        public class FactoryMethodCargoShip : FactoryMethod
        {
            public override AbstractTransoprt CreateTransport()
            {
                return new CargoShip();
            }
            public override void Create(string cargo, string pointA, string pointB)
            {
                TR = CreateTransport();
                TR.Caption = "CargoShip";
                TR.Cargo = cargo;
                TR.PointA = pointA;
                TR.PointB = pointB;
            }
        }
}
