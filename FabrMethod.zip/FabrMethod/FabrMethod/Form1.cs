﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FabrMethod
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        byte type;
        FactoryMethod transport;
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)// доставка
        {
            switch(type)
            {
                case 1:
                    transport = new FactoryMethodCar();
                    transport.Create(textBox3.Text, textBox1.Text, textBox2.Text);
                    listBox1.Items.AddRange(transport.TR.GetMassive());
                    listBox1.Items.Add("---------------------------");
                    break;
                case 2:
                    transport = new FactoryMethodCargoShip();
                    transport.Create(textBox3.Text, textBox1.Text, textBox2.Text);
                    listBox1.Items.AddRange(transport.TR.GetMassive());
                    listBox1.Items.Add("---------------------------");
                    break;
                case 3:
                    transport = new FactoryMethodPlane();
                    transport.Create(textBox3.Text, textBox1.Text, textBox2.Text);
                    listBox1.Items.AddRange(transport.TR.GetMassive());
                    listBox1.Items.Add("---------------------------");
                    break;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)//car
        {
            type = 1;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)//CargoShip
        {
            type = 2;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)// plane
        {
            type = 3;
        }

        private void button2_Click(object sender, EventArgs e)//clear
        {
            listBox1.Items.Clear();
        }
    }
}
