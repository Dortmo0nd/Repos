﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabrMethod
{
    public abstract class AbstractTransoprt
    {
        public string Caption;
        public string PointA;
        public string PointB;
        public string Cargo;
        public abstract string[] GetMassive();
    }
    public abstract class FactoryMethod
    {
        public AbstractTransoprt TR;
        abstract public AbstractTransoprt CreateTransport();
        abstract public void Create(string cargo, string pointA, string pointB);
    }
}
