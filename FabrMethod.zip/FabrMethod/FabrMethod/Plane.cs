﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabrMethod
{
    public class Plane : AbstractTransoprt
    {
        public override string[] GetMassive()
        {
            string[] mas = { "Вид транспорту: " + Caption, "Вантаж: " + Cargo, "Точка А: " + PointA, "Точка Б: " + PointB };
            return mas;
        }
    }
    public class FactoryMethodPlane : FactoryMethod
    {
        public override AbstractTransoprt CreateTransport()
        {
            return new Plane();
        }
        public override void Create(string cargo, string pointA, string pointB)
        {
            TR = CreateTransport();
            TR.Caption = "Plane";
            TR.Cargo = cargo;
            TR.PointA = pointA;
            TR.PointB = pointB;
        }
    }
}
