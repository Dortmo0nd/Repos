﻿using System;
using System.Diagnostics;
interface INotificationStrategy
{
    void Notify(string message);
}
class NotificationService
{
    private INotificationStrategy _strategy;

    public NotificationService()
    {}

    public void SetStrategy(INotificationStrategy strategy)
    {
        this._strategy = strategy;
    }

    public void SendNotification(string message)
    {
        _strategy.Notify(message);
    }
}

class Spotify : INotificationStrategy
{
    public void Notify(string message)
    {
        Console.WriteLine("Hi, this is Spotify: " + message);
    }
}
class AppleMusic : INotificationStrategy
{
    public void Notify(string message)
    {
        Console.WriteLine("Hello i'm AppleMusic: " + message);
    }
}
class YouTube : INotificationStrategy
{
    public void Notify(string mes)
    {
        Console.WriteLine("YouTube: " + mes);
    }
}

class Program
{
    static void Main(string[] args)
    { 
        Console.WriteLine("1 - Spotify " + "2 - YouTube " + "3 - AppleMusic " + "4 - Вихiд");
        var notificationService = new NotificationService();
        bool ex = false;
        while(!ex)
        {
            int x = int.Parse(Console.ReadLine());
            switch (x)
            {
                case 1:
                    notificationService.SetStrategy(new Spotify());
                    Console.WriteLine("Now strategy is 'Spotify'");
                    notificationService.SendNotification("check this playlist that was made based on your preferences\n");
                break;

                case 2:
                    notificationService.SetStrategy(new YouTube());
                    Console.WriteLine("Now strategy is 'YouTube'");
                    notificationService.SendNotification("heey i found some video for you, would you like to watch?\n");
                break;

                case 3:
                    notificationService.SetStrategy(new AppleMusic());
                    Console.WriteLine("Now strategy is 'AppleMusic'");
                    notificationService.SendNotification("your subsciption is ended, would you like to continue? \n");
                break;

                case 4:
                    ex = true;
                break;
            }
        }
    }
}