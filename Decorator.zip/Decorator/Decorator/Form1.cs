﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Decorator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            rectangle.g = this.CreateGraphics();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            rectangle rec = new rectangle();
            if (checkBox1.Checked)
            {
                rec = new DecorateRedTriangle(rec);
                Console.WriteLine("Червоний прямокутник");
                rec.draw();
            }

            if (checkBox2.Checked)
            {
                rec = new DecorateYellowTriangle(rec);
                Console.WriteLine("Жовтий прямокутник");
                rec.draw();
            }

            if (checkBox3.Checked)
            {
                rec = new DecorateGreenTriangle(rec);
                Console.WriteLine("Зелений прямокутник");
                rec.draw();
            }

            if (checkBox4.Checked)
            {
                rec = new DecorateBlueTriangle(rec);
                Console.WriteLine("Синiй прямокутник");
                rec.draw();
            }
            rec.draw();
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                checkBox1.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                checkBox2.Checked = false;
                checkBox1.Checked = false;
                checkBox4.Checked = false;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox1.Checked = false;
            }
        }
    }
}
