﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator
{
    public class rectangle
    {
        public Point p;
        public Size size;
        public static Graphics g;

        public rectangle()
        {
            p.X = 120;
            p.Y = 80;
            size = new Size(150, 100);
        }
        public virtual void draw()
        {
            Rectangle r = new Rectangle(p,size);
            Pen penBlack = new Pen(Color.Black,3);
            g.DrawRectangle(penBlack, r);
        }
    }

    public abstract class AbstractDecorator : rectangle
    {
        protected rectangle obj;

        public AbstractDecorator(rectangle a)
        {
            obj = a;
        }
        public override void draw()
        {

        }
    }

    public class DecorateRedTriangle : AbstractDecorator
    {
        public DecorateRedTriangle(rectangle a) : base(a)
        {
            obj = a;
        }
        public override void draw()
        {
            obj.draw();
            Rectangle r = new Rectangle(p, size);
            Pen penRed = new Pen(Color.Red, 3);
            g.DrawRectangle(penRed, r);
        }
    }
    public class DecorateYellowTriangle : AbstractDecorator
    {
        public DecorateYellowTriangle(rectangle a) : base(a)
        {
            obj = a;
        }
        public override void draw()
        {
            obj.draw();
            Rectangle r = new Rectangle(p, size);
            Pen penYellow = new Pen(Color.Yellow, 3);
            g.DrawRectangle(penYellow, r);
        }
    }
    public class DecorateGreenTriangle : AbstractDecorator
    {
        public DecorateGreenTriangle(rectangle a) : base(a)
        {
            obj = a;
        }
        public override void draw()
        {
            obj.draw();
            Rectangle r = new Rectangle(p, size);
            Pen penGreen = new Pen(Color.Green, 3);
            g.DrawRectangle(penGreen, r);
        }
    }
    public class DecorateBlueTriangle : AbstractDecorator
    {
        public DecorateBlueTriangle(rectangle a) : base(a)
        {
            obj = a;
        }
        public override void draw()
        {
            obj.draw();
            Rectangle r = new Rectangle(p, size);
            Pen penBlue = new Pen(Color.Blue, 3);
            g.DrawRectangle(penBlue, r);
        }
    }
}
